%% Part One
clc; clear;

% creating the impulse function
x = zeros(1, 500);
x(1) = 1;

y1 = System01(x);
y2 = System02(x);

x = 1 : 500;
figure
plot(y1)
xlabel('y'); xlabel('x'); title('System1(\delta[n])');
grid on

figure
plot(y2)
xlabel('y'); xlabel('x'); title('System2(\delta[n])');
grid on

figure
plot(abs(y2-y1))
xlabel('|y_2-y_1|'); xlabel('x'); title('|System1(\delta[n]) - System2(\delta[n])|');
grid on


%% Part 2

% Using Matlab's curve fitting app
%General model:
%     f(x) = k*exp(-a*x)*sin(w*x)
%Coefficients (with 95% confidence bounds):
%       a =     0.01257  (0.01257, 0.01257)
%       k =           1  (1, 1)
%       w =     0.06283  (0.06283, 0.06283)
cftool('fit.sfit')

w = 0.06283;
a = 0.01257;

syms n z;
h = sin(w*n) * exp(-a*n);

figure
fplot(h);
xlim([0,500]);
ylim([-1,1]);
xlabel('h[n]'); xlabel('n'); title('Interpolated h[n]');
grid on

H = ztrans (h);
disp('H(z) = '); pretty(H);
figure
zplane([0 exp(1257/100000)*sin(6283/100000) 0],[exp(1257/50000) -2*cos(6283/100000)*exp(1257/100000) 1])
title('Zeroes and poles of H(z)');

%% Part 4

for f0 = [100, 167, 100*pi, 200, 300, 400]

    t = 0:0.001:1-0.001;
    x = sin(2*pi*f0*t);
    y1 = System01(x);
    y = y1(501:1000); %% this is to remove the transient part of signal
    
    % Plotting the frequency spectrum of output:
    L = length(y);
    Y = fft(y);
    P2 = abs(Y/L);
    P1 = P2(1:L/2+1);
    P1(2:end-1) = 2*P1(2:end-1);
    f = 1000*(0:(L/2))/L;
    figure
    plot(f,P1)
    title(['Amplitude Spectrum of System01 to input with f = ', num2str(f0)])
    xlabel('f (Hz)')
    ylabel('|P(f)|')
end


%% Part 4   - Another test of linearity

% Test # 2
clear
t = 0:0.001:1;

x1 = exp(t);
x2 = sin(t);

y1 = System01(x1);
y2 = System01(x2);
y = System01(x1+x2);
figure
plot(y - y1 - y2);
title('y - y_1 - y_2  for Test # 2'); ylabel('y'); xlabel('n');

% Test # 3
clear
t = 0:0.001:1;

x1 = sin(1000.*(t)) + cos (500 .* t);
x2 = sin(100.*(t));

y1 = System01(x1);
y2 = System01(x2);
y = System01(x1+x2);
figure
plot(y - y1 - y2);
title('y - y_1 - y_2  for Test # 3'); ylabel('y'); xlabel('n');

% Test # 4
clear
t = 0:0.001:1;

x1 = cos(t);
x2 = exp(-100.*t).*cos(t);

y1 = System01(x1);
y2 = System01(x2);
y = System01(x1+x2);
figure
plot(y - y1 - y2);
title('y - y_1 - y_2  for Test # 4'); ylabel('y'); xlabel('n');

%% Part 5

for f0 = [100, 167, 100*pi, 200, 300, 400]

    t = 0:0.001:1-0.001;
    x = sin(2*pi*f0*t);
    y1 = System02(x);
    y = y1(501:1000); %% this is to remove the transient part of signal
    
    % Plotting the frequency spectrum of output:
    L = length(y);
    Y = fft(y);
    P2 = abs(Y/L);
    P1 = P2(1:L/2+1);
    P1(2:end-1) = 2*P1(2:end-1);
    f = 1000*(0:(L/2))/L;
    figure
    plot(f,log(P1))
    title(['Amplitude Spectrum of System02 to input with f = ', num2str(f0)])
    xlabel('f (Hz)')
    ylabel('log|P(f)|')
end

%% part 5 cont.
for f0 = [217, 167, 168, 314]

    t = 0:0.001:1-0.001;
    x = sin(2*pi*f0*t);
    y1 = System02(x);
    y = y1(501:1000); %% this is to remove the transient part of signal
    
    % Plotting the frequency spectrum of output:
    L = length(y);
    Y = fft(y);
    P2 = abs(Y/L);
    P1 = P2(1:L/2+1);
    P1(2:end-1) = 2*P1(2:end-1);
    f = 1000*(0:(L/2))/L;
    figure
    plot(f,log(P1))
    title(['Amplitude Spectrum of System02 to input with f = ', num2str(f0)])
    xlabel('f (Hz)')
    ylabel('log|P(f)|')
end

%% Part 5
clear
t = 1:1000;
warning on

x  = sin(t);
x_  = sin(t) + 1;

y1 = System01(x);
y2 = System02(x);

y1_ = System01(x_);
y2_ = System02(x_);

figure
subplot(2,1,1)
hold on
plot(y1)
plot(y2)
title('x = sin(t)');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');

subplot(2,1,2)
hold on
plot(y1_)
plot(y2_)
title('x = sin(t) + 1');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');



%%
clear
t = 1:1000;

x  = square(t);
x_  = square(t) + 1;

y1 = System01(x);
y2 = System02(x);

y1_ = System01(x_);
y2_ = System02(x_);

figure
subplot(2,1,1)
hold on
plot(y1)
plot(y2)
title('x = square(t)');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');

subplot(2,1,2)
hold on
plot(y1_)
plot(y2_)
title('x = square(t) + 1');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');


%%
clear
t = 1:1000;

x  = sawtooth(t);
x_  = sawtooth(t) + 1;

y1 = System01(x);
y2 = System02(x);

y1_ = System01(x_);
y2_ = System02(x_);

figure
subplot(2,1,1)
hold on
plot(y1)
plot(y2)
title('x = sawtooth(t)');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');

subplot(2,1,2)
hold on
plot(y1_)
plot(y2_)
title('x = sawtooth(t) + 1');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');

%%
clear
t = 0:1000;
x  = heaviside(t);
x_ = x - mean(x);

y1 = System01(x);
y2 = System02(x);
y1_ = System01(x_);
y2_ = System02(x_);

figure
subplot(2,1,1)
hold on
plot(y1)
plot(y2)
title('x = heaviside(t)');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');

subplot(2,1,2)
hold on
plot(y1_)
plot(y2_)
title('x = heaviside(t) - mean(heaviside)');
xlabel('t');
ylabel('OUTPUT');
legend('System01','System02');
