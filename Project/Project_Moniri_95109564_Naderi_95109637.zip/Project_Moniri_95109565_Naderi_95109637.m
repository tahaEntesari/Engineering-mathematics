%% Question One
% Part One
syms n z a c k

x =@(n) a^n * heaviside(n+0.5);
X = ztrans(x, n, z);
disp('X[z] = ')
pretty(X)

y = n*x;
Y = ztrans(y, n, z);
disp('Y[z] = ')
pretty(Y)

w = c^n * x;
W = ztrans(w, n, z);
disp('W[z] = ')
pretty(W)

t = symsum(x(k),k,0,n);
T = ztrans(t, n, z);
disp('T[z] = ')
pretty(T)

r = x(n+1);
R = ztrans(r, n ,z);
disp('R[z] = ')
pretty(R)


%% Question Two
clear
syms n z a c k
% Part 1
x1 = ((1/3)^n + 3^n);
disp('x1[n] = ');
pretty(x1);


disp('Z Transform of x1[n] = ');
pretty(ztrans(x1));

% Part 4
X2 = (10*z-6*z^2)/(-3*z^2 + 10*z - 3);

y = iztrans(X2) % ROC : |z| > 3


% Part 5
figure
zplane([-6,10,0],[-3,10,-3])
title('Zeroes and ploes of X_2(z)');


%% Question Three
% part 2:
syms z
X = 1/(z^2 - 3*z + 2);
zplane([0 0 1],[1 -3 2]);
title('zeroes and poles of X(z)');
legend('zeroes','poles');
[r,p,k]=residuez([0;1],[1;-3;2])
disp('x[n] =');
iztrans(r(1)/(z-p(1))) + iztrans(r(2)/(z-p(2)))

 %% part 3:
clear;
warning off
t = linspace(0,2*pi,100);
C = 5*exp(1j*t);

H = @(z) 1./((z-1).*(z-2));

for n = 1:16
    X = @(z) 1./(2.*pi.*1j) .* z.^(n-2).* H(z);
    N = n-1
    x(n) = integral(X, 0, 0, 'Waypoints' , C)
end

figure
h = 0:15;
stem(h, x);
ylabel('x[n]'); xlabel('n'); title('x[n] as a function of n');
